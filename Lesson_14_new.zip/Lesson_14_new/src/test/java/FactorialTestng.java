import org.example.Factorial;

import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.expectThrows;

public class FactorialTestng {

    @Test
    public void testFactorialPositive() {
        assertEquals(Factorial.execute(5), 120);
    }

    @Test
    public void testFactorialZero() {
        assertEquals(Factorial.execute(0), 1);
    }

    @Test
    public void testFactorialNegative() {
        expectThrows(IllegalArgumentException.class, () -> Factorial.execute(-1));
    }
}