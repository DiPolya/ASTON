import org.example.Arifmetica;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.expectThrows;

public class ArifmeticaTestng {

    @Test
    public void testAddition() {
        assertEquals(Arifmetica.add(20, 3), 23);
    }

    @Test
    public void testSubtraction() {
        assertEquals(Arifmetica.subtract(17, 5), 12);
    }

    @Test
    public void testMultiplication() {
        assertEquals(Arifmetica.multiply(3, 5), 15);
    }

    @Test
    public void testDivision() {
        assertEquals(Arifmetica.divide(24, 3), 8);
    }

    @Test
    public void testDivideByZero() {
        expectThrows(ArithmeticException.class, () -> Arifmetica.divide(9, 0));
    }
}
