import org.example.Triangle;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.expectThrows;

public class TriangleTestng {

    @Test
    public void testAreaNormal() {
        assertEquals(Triangle.areaTriangle(6, 5), 15.0);
    }

    @Test
    public void testAreaZero() {
        assertEquals(Triangle.areaTriangle(0, 12), 0.0);
    }
}