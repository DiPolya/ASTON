import org.example.Comparer;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ComparerTestng {
    @Test
    public void testComparer(){
        Assert.assertEquals(-1, Comparer.compare(1,10));
        Assert.assertEquals(-0, Comparer.compare(1,1));
        Assert.assertEquals(1, Comparer.compare(12,10));
    }
}
